import SpamCallBingo from "@/components/SpamCallBingo";

export default function Home() {
  return (
    <div className="bg-gray-100 min-h-screen font-sans text-gray-900">
      <SpamCallBingo />
    </div>
  );
}
